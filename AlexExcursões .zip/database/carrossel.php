<?php
include('bancodedados.php');

$sql = "SELECT * FROM `carrossel`";
$dados = mysqli_query($connect, $sql) or die (mysqli_error());
$carrossel = mysqli_fetch_all($dados);

foreach($carrossel as $chave => $valor):
      echo("
      <div class='carousel-item'>
        <img class='d-block w-100' src='$valor[1]' alt='Terceiro Slide'>
      </div>
      ");
    endforeach;