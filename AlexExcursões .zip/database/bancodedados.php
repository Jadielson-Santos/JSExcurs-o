<?php



$username = "chamae98_alex";
$servername = "162.241.203.92:3306";
$password = "alex2020"; 
$database = "chamae98_alexexcucoes";

// conectando ao banco de dados
$connect = mysqli_connect($servername, $username, $password, $database);
if(mysqli_connect_error()):
  echo "Erro na conex達o".mysqli_connect_error();
endif;