<?php
include('bancodedados.php');

$sql = "SELECT * FROM `viagens`";

$dados = mysqli_query($connect, $sql) or die (mysqli_error());
$viagens = mysqli_fetch_all($dados);

    foreach($viagens as $chave => $valor):
      $dataida = $valor[5];
      $datavolta = $valor[6];
      $partesida = explode("-", $dataida);
      $partesvolta = explode("-", $datavolta);
      $anoida = $partesida[0];
      $mesida = $partesida[1];
      $diaida = $partesida[2];
      
      $anovolta = $partesvolta[0];
      $mesvolta= $partesvolta[1];
      $diavolta = $partesvolta[2];
      echo("
      <div class='col-sm-6'>
        <div class='card shadow'>
          <img class='card-img-top' src='$valor[2]' alt='Imagem de capa do card'>
          <div class='card-body'>
            <h5 class='card-title'>$valor[1]</h5>
            <h6 class='card-subtitle mb-4'>$diaida/$mesida a $diavolta/$mesvolta</h6>
            <p class='card-text text-muted'>Incluso: $valor[4] <span class='valor'>R$$valor[7]</span></p>
            <a href='reservas/?reserva=$valor[0]' class='btn btn-reserva'>Reservar</a>
          </div>
        </div>
      </div>
      ");
    endforeach;