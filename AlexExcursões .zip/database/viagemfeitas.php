<?php
include('bancodedados.php');

$sql = "SELECT * FROM `viagemfeitas`";
$dados = mysqli_query($connect, $sql) or die (mysqli_error());
$viagemfeitas = mysqli_fetch_all($dados);

foreach($viagemfeitas as $chave => $valor):
      $dataida = $valor[4];
      $datavolta = $valor[5];
      $partesida = explode("-", $dataida);
      $partesvolta = explode("-", $datavolta);
      $anoida = $partesida[0];
      $mesida = $partesida[1];
      $diaida = $partesida[2];
      
      $anovolta = $partesvolta[0];
      $mesvolta= $partesvolta[1];
      $diavolta = $partesvolta[2];
      echo("
      <div class='col-sm-6'>
        <div class='card shadow'>
          <img class='card-img-top' src='$valor[1]' alt='Imagem de capa do card'>
          <div class='card-body'>
            <h5 class='card-title'>$valor[3]</h5>
            <h6 class='card-subtitle mb-4'>$diaida/$mesida a $diavolta/$mesvolta</h6>
            <p class='card-text text-muted'>Incluso: $valor[3]</p>
          </div>
        </div>
      </div>
      ");
    endforeach;