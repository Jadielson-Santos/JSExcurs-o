<?php

include('../../database/bancodedados.php');
// Variáveis da publicação
function redirecionar(){
  header("location: http://chamaeu.space/jsexcursao/adm");
}

if(isset($_POST['adiciona'])){
$titulo = $_POST['titulo'];
$descricao = $_POST['descricao'];
$saida = $_POST['saida'];
$pagamentos = $_POST['pagamentos'];
$valor = $_POST['valor'];
$parcela = $_POST['parcelas'];
$vagas = $_POST['vagas'];


if(isset($_FILES['arquivo'])){
  echo('adiciona');
  if($_FILES['arquivo']['size'] != 0){
    $arquivo = $_FILES['arquivo'];
  if($arquivo['size'] > 5000000)die("<script>alert(\"Erro tamanho\")</script>");
  $pasta = "../../img/";
  $nomeDoArquivo = $arquivo['name'];
  $novoNomeDoArquivo = uniqid();
  $extecao = strtolower(pathinfo($nomeDoArquivo, PATHINFO_EXTENSION));
  $caminho = $novoNomeDoArquivo.".".$extecao;
  $result = move_uploaded_file($arquivo['tmp_name'], $pasta.$novoNomeDoArquivo.".".$extecao);
  
  // Sql do update
  $sql = "INSERT INTO `viagens` (`id`, `nome`, `img`, `titulo`, `descricao`, `data`, `volta`, `valor`, `parcela`, `vagas`, `pagamentos`, `horario`, `saida`) VALUES (NULL, '$titulo', 'http://chamaeu.space/jsexcursao/img/$caminho', '$titulo', '$descricao', '2022-09-28', '2022-09-23', '$valor', '$parcela', '$vagas', '$pagamentos', '18:47:18.000000', '$saida')";

  $dados = mysqli_query($connect, $sql) or die (mysqli_error());
  redirecionar();
  }
  }
}else{
  $id = $_POST['id'];
$titulo = $_POST['titulo'];
$descricao = $_POST['descricao'];
$saida = $_POST['saida'];
$pagamentos = $_POST['pagamentos'];
$valor = $_POST['valor'];
$parcela = $_POST['parcelas'];
$vagas = $_POST['vagas'];
  if($_FILES['arquivo']['name'] == ''){
    $sql = "UPDATE `viagens` SET `titulo` = '$titulo', `descricao` = '$descricao', `saida` = '$saida', `pagamentos` = '$pagamentos', `valor` = '$valor', `parcela` = '$parcela', `vagas` = '$vagas' WHERE `viagens`.`id` = $id";
    $dados = mysqli_query($connect, $sql) or die (mysqli_error());
  redirecionar();

  }else {
    echo('Nao tem arquivo');
    if($_FILES['arquivo']['size'] != 0){
    $arquivo = $_FILES['arquivo'];
  if($arquivo['size'] > 5000000)die("<script>alert(\"Erro tamanho\")</script>");
  $pasta = "../../img/";
  $nomeDoArquivo = $arquivo['name'];
  $novoNomeDoArquivo = $id;
  $extecao = strtolower(pathinfo($nomeDoArquivo, PATHINFO_EXTENSION));
  $caminho = $novoNomeDoArquivo.".".$extecao;
  $result = move_uploaded_file($arquivo['tmp_name'], $pasta.$novoNomeDoArquivo.".".$extecao);
  
  // Sql do update
  $sql = "UPDATE `viagens` SET `titulo` = '$titulo', `descricao` = '$descricao', `saida` = '$saida', `pagamentos` = '$pagamentos', `valor` = '$valor', `img` = 'http://chamaeu.space/jsexcursao/img/$caminho', `parcela` = '$parcela', `vagas` = '$vagas' WHERE `viagens`.`id` = $id";

  $dados = mysqli_query($connect, $sql) or die (mysqli_error());
  redirecionar();
  }
  }
}