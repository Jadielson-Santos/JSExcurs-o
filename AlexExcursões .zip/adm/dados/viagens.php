<?php
include("../database/bancodedados.php");

$sql = 'SELECT * FROM `viagens`';

$dados = mysqli_query($connect, $sql) or die (mysqli_error());
$viagens = mysqli_fetch_all($dados);
foreach($viagens as $chave => $valor):
  $dataida = $valor[5];
  $datavolta = $valor[6];
  $partesida = explode('-', $dataida);
  $partesvolta = explode('-', $datavolta);
  $anoida = $partesida[0];
  $mesida = $partesida[1];
  $diaida = $partesida[2];
  
  $anovolta = $partesvolta[0];
  $mesvolta= $partesvolta[1];
  $diavolta = $partesvolta[2];
  echo("
<div class='col-md-6'>
    <div class='card shadow'>
      <img class='card-img-top' src='$valor[2]' alt='Imagem de capa do card'>
      <div class='card-body'>
        <h5 class='card-title'>$valor[1]</h5>
        <h6 class='card-subtitle mb-4'>$diaida/$mesida a $diavolta/$mesvolta</h6>
        <p class='card-text text-muted'>Incluso: $valor[4]</p>
        <div class='card-text'>
          <p class='text-muted'>Saida:<span class='valor'> $valor[12]</span></p>
          <p class='text-muted'>Pagamentos:<span class='valor'> $valor[10]</span></p>
          <p class='text-muted'>Valor:<span class='valor'> R$$valor[7] ate $valor[8]× no cartão</span></p>
          <p class='text-muted'>Vagas:<span class='valor'> $valor[9] Vagas disponível</span></p>
          <div class='d-flex'>
            <a style='background-color:#046865;color: aliceblue' class='btn btn-reserva m-2' data-toggle='modal' data-target='#modal$valor[0]'>Edita</a>
            <a style='background-color: orangered;' href='adm/apaga/?id=$valor[0]' class='btn btn-reserva apaga m-2'>Apagar</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->
  <div class='modal fade' id='modal$valor[0]' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    <div class='modal-dialog' role='document'>
      <div class='modal-content'>
        <div class='modal-header'>
          <h5 class='modal-title' id='exampleModalLabel'>Edita viagem</h5>
          <button type='button' class='close' data-dismiss='modal' aria-label='Fechar'>
            <span aria-hidden='true'>&times;</span>
          </button>
        </div>
        <div class='modal-body'>

          <form action='atualiza/' method='post' enctype='multipart/form-data'>
            <div class='form-group'>
              <label for='inputAddress'>Titulo</label>
              <input name='titulo' type='text' class='form-control' id='inputAddress' placeholder='$valor[1]' value='$valor[1]'>
            </div>
            <div class='form-group'>
              <label for='inputAddress2'>Incluso</label>
              <input name='descricao' type='text' class='form-control' id='inputAddress2' placeholder='$valor[4]' value='$valor[4]'>
            </div>

            <div class='form-group'>
              <label for='inputAddress2'>Vagas</label>
              <input name='vagas' type='text' class='form-control' id='inputAddress2' placeholder='$valor[9]' value='$valor[9]'>
            </div>

            <div class='form-group'>
              <label for='inputCity'>Saida</label>
              <input name='saida' type='text' class='form-control' id='inputCity' placeholder='$valor[12]' value='$valor[12]'>
            </div>
            <div class='form-group'>
              <label for='inputPagamentos'>Pagamentos</label>
              <input name='pagamentos' type='text' class='form-control' id='inputPagamentos' placeholder='$valor[10]' value='$valor[10]'>
            </div>
            <div class='form-row'>
              <div class='form-group col-md-6'>
                <label for='inputValor'>Valor</label>
                <input name='valor' type='text' class='form-control' id='inputValor' placeholder='R$$valor[7]' value='$valor[7]'>

              </div>
              <div class='form-group col-md-6'>
                <label for='inputValor'>Parcelas</label>
                <input name='parcelas' type='text' class='form-control' id='inputValor' placeholder='$valor[8]' value='$valor[8]'>
              </div>
              <div class='form-group'>
                <label for='arquivo'>Imagem</label>
                <input name='arquivo' type='file' class='form-control' id='arquivo' >
              </div>
            </div>
            <div class='modal-footer'>
              <button type='button' class='btn btn-secondary' data-dismiss='modal'>Fechar</button>
              <button type='submit' class='btn btn-primary' name='id' value='$valor[0]'>Salvar mudanças</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  ");
  endforeach;