<?php

include('../../database/bancodedados.php');

$id = $_GET['id'];

$sql = "DELETE FROM `viagens` WHERE `viagens`.`id` = $id";

$result = mysqli_query($connect, $sql) or die (mysqli_error());
if($result){
  header("location: http://chamaeu.space/jsexcursao/adm");
}