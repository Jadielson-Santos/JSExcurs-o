
function ir() {
  window.location.href = 'https://bit.ly/WhatsApp-AlexExcursoes';
}
$('#myCollapsible').collapse({
  toggle: false
})