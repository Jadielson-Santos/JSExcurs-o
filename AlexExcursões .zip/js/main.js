function sobre() {
  var alerta = document.getElementById('alerta').classList.contains('none')
  if (alerta) {
    document.getElementById('alerta').classList.remove('none')
  } else {
    document.getElementById('alerta').classList.add('none')
  }
  
}

function ir() {
  window.location.href = 'https://bit.ly/WhatsApp-AlexExcursoes';
}

elemento = document.getElementsByClassName('carousel-item')
elemento[0].classList.add('active')